/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.virtualrecipe.business.interfaces;

import br.com.virtualrecipe.dominio.Consultorio;
import java.util.List;

/**
 *
 * @author melis_000
 */
public interface ConsultorioInterface {
    public Consultorio cadastrarConsultorio(Consultorio consultorio);
    public List<Consultorio> buscarConsultorioPorNome(String nome);
    public List<Consultorio> buscarConsultorioPorTelefone(Integer telefone);
    public List<Consultorio> buscarTodosConsultorios();
}
